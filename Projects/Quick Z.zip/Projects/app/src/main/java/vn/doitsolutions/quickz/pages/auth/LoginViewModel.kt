package vn.doitsolutions.quickz.pages.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import vn.doitsolutions.quickz.model.Login
import vn.doitsolutions.quickz.model.LoginData
import vn.doitsolutions.quickz.network.LoginApi

class LoginViewModel: ViewModel() {

    var username: String = ""
    var password: String = ""
    var loginStatus: String = "init"
    var message: String = ""

    init{
    }

     fun login(){
     viewModelScope.launch {
         try {
             message = "Đang đăng nhập..."
             val userResponseObject = LoginApi.retrofitService.login(Login(route= "login", data = LoginData(username = username, password = password)))
             println("Cera: " + userResponseObject.data?.username)
             loginStatus = "success"
             message = "Đăng nhập thành công"

         }catch (e: Exception){
             println("CERA: " + e.message)
             loginStatus = "fail"
             message = e.message.toString()
         }


     }
    }
}