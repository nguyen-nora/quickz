package vn.doitsolutions.quickz.model

import com.google.gson.annotations.SerializedName
import com.squareup.moshi.Json


data class User (
    @Json( name = "username") var username: String,
    @Json( name = "password") var password: String,
    @Json( name = "fullname") var fullname: String,
    @Json( name = "id") var id: String,
    @Json( name = "_rowPosition") var _rowPosition: Int
    )
