package vn.doitsolutions.quickz.model

import com.squareup.moshi.Json

data  class UserResponseObject (
    @Json( name = "status") val status: String,
    @Json( name = "msg") val msg: String,
    @Json( name = "data") val data: User?
)


//{"status":"OK","msg":"","data":{"_rowPosition":2,"id":"5b9dfb4e-627c-4d9b-aad6-bc2b47e4af62","username":"user1","password":"abc123","fullname":"User Test 1"}}